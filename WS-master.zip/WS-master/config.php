;******************************************************************************

; Nome do Arquivo   : config.ini

; Descrição         : Arquivo de configuração do sistema

; Programador       : Alberto Medeiros

; Data              : 31/08/2016

;******************************************************************************
[mysql]


ipMysql = producao_imip.mysql.dbaas.com.br

dbMysql = dev_imip

userMysql = dev_imip

passMysql = wESv6rHfAtxmH2
